<footer class="bg-white border-t border-gray-200 py-4 text-center text-sm text-gray-500">
    &copy; 2025 PT Karya Wiguna. All rights reserved.
</footer>
