<?php

use Illuminate\Support\Facades\Facade;

return [
    // Banyaknya digit antrian yang ditampilkan
    'total_locket_queue' => '3',
    // Total Lantai yang ada
    'total_lantai' => '3',
    // total loket yang ada
    'total_loket' => '5',
    // enable disable printer
    'printer_on' => false,
];
