<?php return array (
  'poli.active-queue' => 'App\\Http\\Livewire\\Poli\\ActiveQueue',
  'queue-manager' => 'App\\Http\\Livewire\\QueueManager',
);