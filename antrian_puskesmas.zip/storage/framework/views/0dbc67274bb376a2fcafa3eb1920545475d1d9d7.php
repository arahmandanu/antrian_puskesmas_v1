<div>
    <p class="text-gray-700 text-sm mb-2">
        No terakhir: <span class="font-semibold"><?php echo e($currentQueue); ?></span>
    </p>
    <p class="text-gray-700 text-sm">
        Lantai: <span class="font-semibold"><?php echo e($lantai); ?></span>
    </p>
</div>
<?php /**PATH C:\wamp64\www\antrian_puskesmas_v1\resources\views/livewire/queue-manager.blade.php ENDPATH**/ ?>