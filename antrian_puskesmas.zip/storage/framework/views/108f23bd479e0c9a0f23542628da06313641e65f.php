<?php $__env->startSection('content'); ?>
    <main class="flex justify-center flex-grow overflow-y-auto h-screen custom-scrollbar bg-gray-50">
        <div class="max-w-7xl w-full mx-auto p-6">
            <!-- Title -->
            <h2 class="text-3xl font-bold mb-8 text-center text-gray-800 tracking-tight">
                Silakan Pilih Poli Antrian
            </h2>

            <!-- Grid Poli -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php $__empty_1 = true; $__currentLoopData = $polis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div
                        class="bg-white rounded-2xl shadow-md hover:shadow-xl hover:-translate-y-1 transform transition-all duration-300 flex flex-col overflow-hidden">

                        <!-- Header -->
                        <div
                            class="flex flex-col items-center bg-gradient-to-r from-indigo-500 to-purple-600 p-6 text-white">
                            <span class="text-5xl mb-2">🩺</span>
                            <h3 class="text-lg font-bold tracking-wide"><?php echo e(Str::upper($poli->name)); ?></h3>
                        </div>

                        <!-- Body -->
                        <div class="flex flex-col flex-grow items-center p-5 text-center">
                            <p class="text-gray-700 text-sm mb-2">
                                No terakhir: <span class="font-semibold"><?php echo e($poli->current_queue ?? '-'); ?></span>
                            </p>
                            <p class="text-gray-700 text-sm">
                                Lantai: <span class="font-semibold"><?php echo e($poli->lantai); ?></span>
                            </p>
                        </div>

                        <!-- Footer -->
                        <div class="grid grid-cols-2 gap-3 p-4 bg-gray-50 border-t border-gray-100">
                            <a href="<?php echo e(route('poli.generateView', $poli->id)); ?>"
                                class="px-4 py-2 rounded-lg bg-blue-500 text-white text-sm font-medium text-center shadow hover:bg-blue-600 transition">
                                Loket Staff
                            </a>
                            <a href="<?php echo e(route('poli.showQueueByRoom', $poli->id)); ?>"
                                class="px-4 py-2 rounded-lg bg-green-500 text-white text-sm font-medium text-center shadow hover:bg-green-600 transition">
                                Antrian Customer
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- Empty State -->
                    <div
                        class="bg-white border-2 border-red-500 rounded-2xl shadow-sm p-10 flex flex-col items-center justify-center text-center">
                        <span class="text-5xl mb-4">❌</span>
                        <h3 class="text-xl font-bold text-red-600 mb-2">Tidak ada Poli yang tersedia</h3>
                        <p class="text-gray-600 text-sm">Silakan hubungi admin untuk menambahkan poli baru.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\antrian_puskesmas_v1\resources\views/loket_staff/list_poli.blade.php ENDPATH**/ ?>