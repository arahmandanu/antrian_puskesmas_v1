<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Loket Create</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <form role="form" method="POST" action="<?php echo e(route('admin.loket.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Nama Staff</label>
                                <input class="form-control" name="staff_name" placeholder="Masukkan nama staff" required>
                            </div>

                            <div class="form-group">
                                <label>Letak Poli (lantai)</label>
                                <select class="form-control" required name="lantai">
                                    <?php $__empty_1 = true; $__currentLoopData = $lantaiOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lantai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($lantai); ?>"><?php echo e($lantai); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="">Silahkan hubungi developer anda</option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Nomor Loket</label>
                                <select class="form-control" required name="locket_number">
                                    <?php $__empty_1 = true; $__currentLoopData = $availableLokets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($code); ?>"><?php echo e($code); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="">Sudah Habis (Silahkan hubungi developer anda)</option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-success">Submit</button>

                            <button type="reset" class="btn btn-warning">Reset</button>
                        </form>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.shared.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\antrian_puskesmas_v1\resources\views/admin/loket/create.blade.php ENDPATH**/ ?>