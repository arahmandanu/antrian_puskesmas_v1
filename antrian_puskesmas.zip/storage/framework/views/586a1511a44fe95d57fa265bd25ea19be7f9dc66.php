<?php $__env->startSection('content'); ?>
    <!-- Main -->
    <main class="flex justify-center flex-grow overflow-y-auto h-screen custom-scrollbar ">
        <div class="max-w-6xl w-full p-6">
            <h2 class="text-2xl font-semibold mb-10 text-center text-gray-700">
                Silakan Pilih Loket Antrian anda
            </h2>

            <!-- Grid Loket -->
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">

                <?php $__empty_1 = true; $__currentLoopData = $lokets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <!-- Loket 1 -->
                    <a href="<?php echo e(route('loket_antrian.generateView', $loket->locket_number)); ?>"
                        class="cursor-pointer bg-white border-2 border-green-600 rounded-xl shadow-lg
                 hover:shadow-2xl hover:scale-105 transform transition-all duration-300
                 flex flex-col items-center justify-center p-6">
                        <span class="text-5xl mb-3">🏢</span>
                        <h3 class="text-xl font-bold text-green-700"><?php echo e($loket->staff_name); ?></h3>
                        <p class="text-gray-600 text-sm mt-1">Lantai: <?php echo e($loket->locket_number); ?></p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- Loket 1 -->
                    <div
                        class="cursor-pointer bg-white border-2 border-green-600 rounded-xl shadow-lg
                 hover:shadow-2xl hover:scale-105 transform transition-all duration-300
                 flex flex-col items-center justify-center p-6">
                        <span class="text-5xl mb-3">🏢</span>
                        <h3 class="text-xl font-bold text-green-700">Tidak ada loket staff, silahkan buat dahulu di menu
                            admin anda</h3>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\antrian_puskesmas_v1\resources\views/loket_antrian/list_locket.blade.php ENDPATH**/ ?>