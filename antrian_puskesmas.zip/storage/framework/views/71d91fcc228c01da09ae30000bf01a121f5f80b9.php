<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Detail Puskesmas</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <form role="form" method="POST" action="<?php echo e(route('admin.company.update', $company->id)); ?>">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Puskesmas</label>
                                <input class="form-control" disabled value="<?php echo e($company->name ?? '-'); ?>"
                                    placeholder="Masukkan nama staff">
                            </div>

                            <div class="form-group">
                                <label>Alamat</label>
                                <input class="form-control" value="<?php echo e($company->address ?? '-'); ?>" disabled>
                            </div>

                            <div class="form-group">
                                <label>Printer Loket</label>
                                <input class="form-control" name="printer" value="<?php echo e($company->printer ?? ''); ?>">
                            </div>

                            <div class="form-group">
                                <?php if($company->active ?? false): ?>
                                    <span class="btn btn-success">Active</span>
                                <?php else: ?>
                                    <span class="btn btn-danger">Tidak Active</span>
                                <?php endif; ?>
                            </div>

                            <button type="submit">Save</button>
                        </form>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.shared.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\antrian_puskesmas_v1\resources\views/admin/company/index.blade.php ENDPATH**/ ?>