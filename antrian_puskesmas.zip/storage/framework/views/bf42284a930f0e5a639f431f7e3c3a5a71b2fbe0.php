<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Poli Edit</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <form role="form" method="POST" action="<?php echo e(route('admin.poli.update', $poli->id)); ?>">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Nama Poli</label>
                                <input class="form-control" name="name" placeholder="Masukkan nama poli" required
                                    value="<?php echo e($poli->name ?? ''); ?>">
                            </div>

                            <div class="form-group">
                                <label>Kode Poli</label>
                                <select class="form-control" required name="code">
                                    <?php $__empty_1 = true; $__currentLoopData = $availableCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($code); ?>" <?php echo e($code == $poli->code ? 'selected' : ''); ?>>
                                            <?php echo e($code); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="">Sudah Habis (Silahkan hubungi developer anda)</option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Letak Poli (lantai)</label>
                                <select class="form-control" required name="lantai">
                                    <?php $__empty_1 = true; $__currentLoopData = $lantaiOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lantai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($lantai); ?>"
                                            <?php echo e($poli->lantai == $lantai ? 'selected' : ''); ?>><?php echo e($lantai); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="">Silahkan hubungi developer anda</option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Tampilkan</label>
                                <div class="radio">
                                    <label>
                                        <input type="radio" name="show" id="optionsRadios1" value="1"
                                            <?php echo e($poli->show ? 'checked' : ''); ?>>
                                        ya
                                    </label>
                                </div>
                                <div class="radio">
                                    <label>
                                        <input type="radio" name="show" id="optionsRadios2" value="0"
                                            <?php echo e($poli->show ? '' : 'checked'); ?>>
                                        tidak
                                    </label>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-success">Submit</button>

                            <button type="reset" class="btn btn-warning">Reset</button>
                        </form>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.shared.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\antrian_puskesmas_v1\resources\views/admin/room/edit.blade.php ENDPATH**/ ?>