<?php

namespace App\Services;

class AbstractService
{
    use \App\Helpers\ResponseHelper;
}
